import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.*;

public class MedikamentHinzufueger extends Application implements EventHandler<Event>  {
static BorderPane layout = new BorderPane();
private ChoiceBox<String> choMedikament = new ChoiceBox<String>();
private TextField tfDatum = new TextField();
private Label lbUeberschrifft = new Label ();
private Label lbPatName = new Label();
private Label lbPatId=new Label();
private Label lbMedikament = new Label();
private Label lbDatum = new Label();
private Button btSpeichern = new Button();
private Button btAbbrechen = new Button();
private HBox obenBox = new HBox(100);
private VBox obenLinksBox = new VBox();
private VBox obenRechtsBox = new VBox();
private VBox centerBox = new VBox(8);
private HBox untenBox = new HBox();
public Stage stage;
public Scene scene;

// Textfelder fuer PName and PID  
private TextField tfPName = new TextField();
private TextField tfPid = new TextField();

@Override
public void start (Stage primaryStage){
stage=primaryStage;

lbUeberschrifft.setText("Medikament hinzufügen");
lbUeberschrifft.setFont(Font.font("Arial",20.0));
lbPatName.setText("Patientenname");
lbPatId.setText("Patienten-ID");
lbMedikament.setText("Wählen sie das Medikament:");
lbDatum.setText("geben Sie den Anfang der Einnahme der Medikamente an:");

tfDatum.setPromptText("Datum der Dosierung des Medikaments (jjjj-mm-tt)");
tfDatum.setMaxWidth(180);
btSpeichern.setText("SPEICHERN!");
btSpeichern.addEventHandler(ActionEvent.ACTION, this);
btAbbrechen.setText("Abbrechen");
btAbbrechen.addEventHandler(ActionEvent.ACTION, this);

choMedikament.setItems(SQLInterfaceMA.getMedBez());

obenLinksBox.getChildren().addAll(lbUeberschrifft);
obenLinksBox.setMinWidth(300.0);
obenRechtsBox.getChildren().addAll(lbPatName, tfPName, lbPatId, tfPid);
obenBox.getChildren().addAll(obenLinksBox, obenRechtsBox);
centerBox.getChildren().addAll(lbMedikament, choMedikament,lbDatum, tfDatum);
centerBox.setAlignment(Pos.CENTER);
untenBox.getChildren().addAll(btSpeichern, btAbbrechen);


layout.setTop(obenBox);
layout.setCenter(centerBox);
layout.setBottom(untenBox);

scene = new Scene(layout);

  
  
}

    // Denisa
   // @Override
    //     public void handle(ActionEvent e) {
    //public void handle(Event e) {
      //kundenDaten.add(new Kunde(addFirstName.getText(), addLastName.getText()));
      //SQLInterface2.KundeAnlegenKurz(addFirstName.getText(), addLastName.getText());
      //addFirstName.clear();
      //addLastName.clear();
    
      //if(e.getSource().equals(btSpeichern)){
    
        //System.out.println("test");
        //lbUeberschrifft.setText("LEIDER NOCH NICHT IMPLEMENTIERt");
        
        
      
    //}
      //if (e.getSource().equals(btAbbrechen)){
        //Main.switchGuiUebersicht();
        
  //    }
//}
  
  
  //Rima   
  
  
  
  

//@Override
//public void handle(ActionEvent event) {
   // if (event.getSource().equals(btSpeichern)) {
        //if (isValidInput()) {
            //SQLInterfaceMA.getMedBez(tfV.getText(), tfGebdat.getText(), tfAnschrifft.getText(), tfPlz.getText(), tfOrt.getText(), tfBlutg.getText());
            //choMedikament.getValue();
           // System.out.println("Patient gespeichert!");
            //Main.switchGuiUebersicht();
        //} else {
            //System.out.println("Ungültige Eingabe! Bitte überprüfen Sie Ihre Daten.");
        //}
    //}
//}}





        //if (event.getSource().equals(btAbbrechen)) {
           // Main.switchGuiUebersicht();
        
    // }
     // }
    
      @Override
  public void handle(Event e) {
  if(e.getSource().equals(btSpeichern)){
    
    System.out.println(choMedikament.getValue());
    lbUeberschrifft.setText(getMedBez(tfV.getText(), tfGebdat.getText(), tfAnschrifft.getText(), tfPlz.getText(), tfOrt.getText(), tfBlutg.getText());
    
    
  
}
  if (e.getSource().equals(btAbbrechen)){
    Main.switchGuiUebersicht();
    
  }
}
}
// Programmiert von Olcay Anahtar,Denisa,Rima
 
 
 

          
