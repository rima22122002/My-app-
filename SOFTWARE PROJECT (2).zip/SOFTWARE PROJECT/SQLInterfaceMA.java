import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;  


/**
  *
  * description
  *
  * @version 1.0 from 16.11.2023
  * @author Denisa Papa 
  */

public class SQLInterfaceMA {
  
  // Für Kontaktdaten Ärzte

  public static ObservableList<Arzt> fuelleListeArzt() {
     ObservableList<Arzt> Arlist = FXCollections.observableArrayList();
     try {  
       
    Statement stmt = DBConnectionMobilerArzt.Connect();
    ResultSet rs = stmt.executeQuery("SELECT aid, aname, avorname, afachgebiet, astrasse, aplz, aort, atel FROM t_aerzte");
   //   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
     
        while(rs.next()){
       // System.out.println(rs.getTime("pGebDat"));  //System.out.println(rs.getString("pGebDat"));
        //String gebDat = sqlTimestampToDate(rs.getTimestamp("pGebDat"));


        int aid = rs.getInt("Aid");
        String aname = rs.getString("Aname");
        String avorname = rs.getString("Anachname");        
        String afachgebiet = rs.getString("Afachgebiet");
        String astrasse = rs.getString("Astrasse");
        int aplz = rs.getInt("Aplz");
        String aort = rs.getString("Aort");
        String atel = rs.getString("Atel");
        
        
        /** Holen Sie hier die Informationen aus dem Resultset, um den voll-
          * parametrisierten Konstruktor zu verwenden
          * Auch das Geburtsdatum ist in der DB ein varchar, wer das ändern möchte, hat
          * ein wenig mit Konvertierungen zu tun (s. Kommentare oben )
          */
         Arzt ar = new Arzt(aid, aname, avorname,afachgebiet, astrasse, aplz, aort, atel);
            
         Arlist.addAll(ar);
      }
      
      DBConnectionMobilerArzt.endConnect();
     }catch(Exception ex){
        ex.printStackTrace();
      }     
  
    return Arlist;
  }
  

   
  public static ObservableList<Arzt> getpatArzt(String patName){
       ObservableList<Arzt> patArzt = FXCollections.observableArrayList();
  
     try {
       Statement stmt = DBConnectionMobilerArzt.Connect();
        
        /** Hier benötigen Sie wohl Joins, um vom Patienten zu den Impfungen gelangen
         * weisen Sie dem Resultset rs das entsprechende Statement zu.
         */

       ResultSet rs = stmt.executeQuery("SELECT aid, aname FROM t_aerzte INNER JOIN t_med_pat ON aid = f_aid INNER JOIN t_patienten ON f_pzn = pzn");
  
     
     
       while(rs.next()){  
        Arzt arz = new Arzt(rs.getInt("aid"),rs.getString("aname"), rs.getString("avorname"),rs.getString("afachgebiet"),rs.getString("astrasse"),rs.getInt("aplz"), rs.getString("aort"),rs.getString("atel"));
        patArzt.add(arz);
   
       }    
       DBConnectionMobilerArzt.endConnect();
      }catch(Exception ex){                                                                                                                                 
        ex.printStackTrace();
     }
     return patArzt;
  }
  
  
  
  
      public static ObservableList<Patient> fuelleListePatienten() {
     ObservableList<Patient> Patlist = FXCollections.observableArrayList();
     try {  
       
    Statement stmt = DBConnectionMobilerArzt.Connect();
    ResultSet rs = stmt.executeQuery("SELECT pid, pname, pvorname, pgebdat, pstrasse, pplz, port, pblutg FROM t_patienten"); 
   //   SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
     
        while(rs.next()){
       // System.out.println(rs.getTime("pGebDat"));  //System.out.println(rs.getString("pGebDat"));
        //String gebDat = sqlTimestampToDate(rs.getTimestamp("pGebDat"));


        int pid = rs.getInt("Pid");
        String pname = rs.getString("Pname");
        String pvorname = rs.getString("Pvorname");        
        String pgebdat = rs.getString("pgebdat");
        String pstrasse = rs.getString("Pstrasse");
        int pplz = rs.getInt("Pplz");
        String port = rs.getString("Port");
        String pblutg = rs.getString("Pblutg");
        
        
        /** Holen Sie hier die Informationen aus dem Resultset, um den voll-
          * parametrisierten Konstruktor zu verwenden
          * Auch das Geburtsdatum ist in der DB ein varchar, wer das ändern möchte, hat
          * ein wenig mit Konvertierungen zu tun (s. Kommentare oben )
          */
         Patient pat = new Patient(pid, pname, pvorname,pgebdat, pstrasse, pplz, port, pblutg);
            
         Patlist.addAll(pat);
      }
      
      DBConnectionMobilerArzt.endConnect();
     }catch(Exception ex){
        ex.printStackTrace();
      }     
  
    return Patlist;
  }
           
    public static void patientenAnlegen(String pname, String pvorname, String pgebdat, String pstrasse, String pplz, String port, String pblutg){
    int pati = 0;
    try {
      
      Statement stmt = DBConnectionMobilerArzt.Connect();
      int maxPid = 0;
      int nextPid = 0;
      
      /** Resultset vereinbaren und Statement ausführen, um maximale pid
        * zu holen
         */
      
      ResultSet rs = stmt.executeQuery("SELECT pid AS pid from t_patienten WHERE pid = (SELECT max(pid) FROM t_patienten)");
      rs.next();
      maxPid = rs.getInt("pid");
     
      nextPid = maxPid +1;
      System.out.println(nextPid);
      
       /** Patienten via Insert-Befehl auf stmt in Datenbank einpflegen
         *
         */
      
      int anzahl = stmt.executeUpdate("INSERT INTO t_patienten VALUES(" + nextPid + ",'"+pname+"','" + pvorname + "','"+pgebdat+"','"+pstrasse+"'," + pplz + ",'" + port + "', '" +pblutg + "')");
           
      DBConnectionMobilerArzt.endConnect();
     }catch(Exception ex){
        ex.printStackTrace();
      } 
  }
  
  public static Patient getPatientenDaten(String patienten){
    Patient pat = null;
     try {
        Statement stmt = DBConnectionMobilerArzt.Connect();
       
        /** ResultSet rs erhält auf stmt den SELECT-Befehl zum Auswählen eines Patienten
         * mit seinem Namen
         */

       // int pid = 'SELECT pid FROM t_patienten'
        ResultSet rs = stmt.executeQuery("SELECT pid, pname, pvorname, pgebdat, pstrasse, pplz, port, pblutg FROM t_patienten WHERE pname = " + "'" + patienten + "';");
        //ResultSet rs = stmt.executeQuery("SELECT pid, pname, pvorname, pgebdat, pstrasse, pplz, port, pblutg FROM t_patienten WHERE pname = " + "'" + "Mbathie" + "';");              
        rs.next();
        pat = new Patient(rs.getInt("pid"),rs.getString("pname"),rs.getString("pvorname"),rs.getString("pgebdat"),rs.getString("pstrasse"),rs.getInt("pplz"),rs.getString("port"), rs.getString("pblutg"));
            
        DBConnectionMobilerArzt.endConnect();
      }
      catch(Exception ex){
        ex.printStackTrace();
      }
     return pat;
     
     }
  
       //Medikament Liste ausgeben für ein Patient
  
   public static ObservableList<Medikament> getMedikamente(String patName){
       ObservableList<Medikament> patMedikament = FXCollections.observableArrayList();
  
     try {
       Statement stmt = DBConnectionMobilerArzt.Connect();
        
        /** Hier benötigen Sie wohl Joins, um vom Patienten zu den Impfungen gelangen
         * weisen Sie dem Resultset rs das entsprechende Statement zu.
         */

       ResultSet rs = stmt.executeQuery("SELECT * FROM t_patienten INNER JOIN t_med_pat ON f_pid = pid INNER JOIN t_medikamenten ON f_pzn = pzn INNER JOIN t_aerzte ON f_aid = aid WHERE pname = " + "'" + patName + "';");
  
     
     
       while(rs.next()){  
        Medikament Med = new Medikament(rs.getInt("pzn"),rs.getString("mBez"),rs.getString("mWirkstoff"),rs.getString("mAnteilWirkstoff"),rs.getString("mDarreichungsform"), rs.getString("aname"));
        patMedikament.add(Med);
   
       }    
       DBConnectionMobilerArzt.endConnect();
      }catch(Exception ex){                                                                                                                                 
        ex.printStackTrace();
     }
     return patMedikament;
  }
  
  
    // Medikament hinzufügen 
  
   public static ObservableList<String> getMedBez(){
  ObservableList<String> Medikamente = FXCollections.observableArrayList(); 

   try {
       Statement stmt = DBConnectionMobilerArzt.Connect();
      
       ResultSet rs = stmt.executeQuery("SELECT * FROM t_medikamenten;");

        while(rs.next()){ 
                     
         Medikamente.add(rs.getString("pzn") + ", " + rs.getString("mBez"));
      
        }   
        DBConnectionMobilerArzt.endConnect();
      }catch(Exception ex){
         ex.printStackTrace();
      }
         return Medikamente;
       }
      }
      
    
    
    

