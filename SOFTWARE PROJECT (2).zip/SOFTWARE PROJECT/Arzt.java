import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Arzt {
    private SimpleIntegerProperty aid;
    private SimpleStringProperty aname;
    private SimpleStringProperty avorname;
    private SimpleStringProperty afachgebiet;
    private SimpleStringProperty astrasse;
    private SimpleIntegerProperty aplz;
    private SimpleStringProperty aort;
    private SimpleStringProperty atel;

    public Arzt(Integer aid, String aname, String avorname, String afachgebiet, String astrasse, Integer aplz, String aort, String atel) {
        this.aid = new SimpleIntegerProperty(aid);
        this.aname = new SimpleStringProperty(aname);
        this.avorname = new SimpleStringProperty(avorname);
        this.afachgebiet = new SimpleStringProperty(afachgebiet);
        this.astrasse = new SimpleStringProperty(astrasse);
        this.aplz = new SimpleIntegerProperty(aplz);
        this.aort = new SimpleStringProperty(aort);
        this.atel = new SimpleStringProperty(atel);
    }

    public Integer getAid() {
        return aid.get();
    }

    public void setAid(Integer aid) {
        this.aid.set(aid);
    }

    public SimpleIntegerProperty AidProperty() {
        return aid;
    }

    public String getAName() {
        return aname.get();
    }

    public void setAName(String aname) {
        this.aname.set(aname);
    }

    public SimpleStringProperty ANameProperty() {
        return aname;
    }

    public String getAVorname() {
        return avorname.get();
    }

    public void setAVorname(String avorname) {
        this.avorname.set(avorname);
    }

    public SimpleStringProperty AVornameProperty() {
        return avorname;
    }

    public String getAFachgebiet() {
        return afachgebiet.get();
    }

    public void setAFachgebiet(String afachgebiet) {
        this.afachgebiet.set(afachgebiet);
    }

    public SimpleStringProperty AFachgebietProperty() {
        return afachgebiet;
    }

    public String getAStrasse() {
        return astrasse.get();
    }

    public void setAStrasse(String astrasse) {
        this.astrasse.set(astrasse);
    }

    public SimpleStringProperty AStrasseProperty() {
        return astrasse;
    }

    public Integer getAPlz() {
        return aplz.get();
    }

    public void setAPlz(Integer aplz) {
        this.aplz.set(aplz);
    }

    public SimpleIntegerProperty APlzProperty() {
        return aplz;
    }

    public String getAOrt() {
        return aort.get();
    }

    public void setAOrt(String aort) {
        this.aort.set(aort);
    }

    public SimpleStringProperty AOrtProperty() {
        return aort;
    }

    public String getATel() {
        return atel.get();
    }

    public void setATel(String atel) {
        this.atel.set(atel);
    }

    public SimpleStringProperty ATelProperty() {
        return atel;
    }

    // Programmiert von Olcay
}
