import javafx.application.Application;
import javafx.scene.layout.Pane;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    public static PatientErsteller patCreator;
    public static PatientUebersicht patLis;
    public static MedikamentHinzufueger medikament;
    public static PatientUebersicht patient;
  
    public static Scene scene;
    public static Stage stage;

    @Override
    public void start(Stage primaryStage) {
        patCreator = new PatientErsteller();
        patLis = new PatientUebersicht();
        medikament = new MedikamentHinzufueger();
    
        patCreator.start(stage);
        patLis.start(stage);
        medikament.start(stage);
    
        primaryStage.setTitle("Mobiler Arzt");
        stage = primaryStage;

        //switchGuiErsteller(); // Set the initial scene

        primaryStage.setWidth(618.0);
        primaryStage.setHeight(400.0);
        primaryStage.setScene(patLis.scene);
    
        primaryStage.show(); 
    
            
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static void switchGuiUebersicht() {
        // Add logic to switch to the overview scene
        stage.setScene(PatientUebersicht.scene);
    }

    public static void switchGuiErsteller() {
        // Add logic to switch to the patient creator scene
        stage.setScene(patCreator.scene);
    }

    public static void switchGuiMedikament() {
        // Add logic to switch to the medication scene

        stage.setScene(medikament.scene);


    }
}
