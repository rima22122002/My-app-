import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class Patient {
  private SimpleIntegerProperty pID;
  private SimpleStringProperty pName;
  private SimpleStringProperty pVorname;
  private SimpleStringProperty pGebDat;
  private SimpleStringProperty pStrasse;
  private SimpleIntegerProperty pPlz;
  private SimpleStringProperty pOrt;
  private SimpleStringProperty pBlutg;

  public Patient(int pID, String pName, String pVorname, String pGebDat, String pStrasse, int pPlz, String pOrt, String pblutg) {
    
    this.pID = new SimpleIntegerProperty(pID);
    this.pName = new SimpleStringProperty(pName);
    this.pVorname = new SimpleStringProperty(pVorname);
    this.pGebDat = new SimpleStringProperty(pGebDat);
    this.pStrasse = new SimpleStringProperty(pStrasse);
    this.pPlz = new SimpleIntegerProperty(pPlz);
    this.pOrt = new SimpleStringProperty(pOrt);
    this.pBlutg = new SimpleStringProperty(pblutg);
    
  }

  public Patient(int pID, String pName, String pVorname, String pGebDat) {
    
    this.pID = new SimpleIntegerProperty(pID);
    this.pName = new SimpleStringProperty(pName);
    this.pVorname = new SimpleStringProperty(pVorname);
    this.pGebDat = new SimpleStringProperty(pGebDat);
  }

  public int getpID() {
    return pID.get();
  }

  public void setpID(int pID) {
    this.pID.set(pID);
  }

  public SimpleIntegerProperty pIDProperty(){
    return pID;
  }

  public String getpName() {
    return pName.get();
  }

  public void setpName(String pName) {
    this.pName.set(pName);
  }

  public SimpleStringProperty pNameProperty(){
    return pName;
  }

  public String getpVorname() {
    return pVorname.get();
  }

  public void setpVorname(String pVorname) {
    this.pVorname.set(pVorname);
  }

  public SimpleStringProperty pVornameProperty(){
    return pVorname;
  }

  public String getpGebDat() {
    return pGebDat.get();
  }

  public void setpGebDat(String pGebDat) {
    this.pGebDat.set(pGebDat);
  }

  public SimpleStringProperty pGebDatProperty(){
    return pGebDat;
  }

  public String getpStrasse() {
    return pStrasse.get();
  }

  public void setpStrasse(String pStrasse) {
    this.pStrasse.set(pStrasse);
  }

  public SimpleStringProperty pStrasseProperty(){
    return pStrasse;
  }

  public int getpPlz() {
    return pPlz.get();
  }

  public void setpPlz(int pPlz) {
    this.pPlz.set(pPlz);
  }

  public SimpleIntegerProperty pPlzProperty(){
    return pPlz;
  }

  public String getpOrt() {
    return pOrt.get();
  }

  public void setpOrt(String pOrt) {
    this.pOrt.set(pOrt);
  }

  public SimpleStringProperty pOrtProperty(){
    return pOrt;
  }

  
  public String getpIDAsString(){
    return ""+pID.get();
  }

  public String getpPlzAsString(){
    return ""+pPlz.get();
  }
  
    public String getpBlutg() {
    return pBlutg.get();
  }

  public void setpBlut(String pBlutg) {
    this.pBlutg.set(pBlutg);
  }

  public SimpleStringProperty pBlutgProperty(){
    return pBlutg;
  }
  

}
// Programmiert von Rima