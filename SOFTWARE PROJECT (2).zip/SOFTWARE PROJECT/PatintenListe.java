import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class PatintenListe extends Application {
  
  


    @Override
    public void start(Stage primaryStage) {
        // Erstellen Sie eine ObservableList mit Daten für die Liste
        ObservableList<String> items = FXCollections.observableArrayList(
                "PID", "Name", "Vorname", "GedDat", "Strasse",  "Plz", "Ort", "Bluttgruppe");

        // Erstellen Sie die ListView und setzen Sie die Daten
        ListView<String> listView = new ListView<>(items);

        // Behandeln Sie den Klick auf ein Listenelement
        listView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            System.out.println("Ausgewählt: " + newValue);
            // Hier können Sie weitere Aktionen für die Auswahl durchführen
        });

        // Erstellen Sie die Szene und setzen Sie die ListView darauf
        Scene scene = new Scene(listView, 300, 200);

        // Setzen Sie die Szene für die Bühne und zeigen Sie sie an
        primaryStage.setScene(scene);
        primaryStage.setTitle("Patienten Liste");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
 // Programmiert von Rima