import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.collections.*;
import javafx.scene.text.Font;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;

public class PatientErsteller extends Application implements EventHandler<ActionEvent> {

    private Label lbAnzeige = new Label();
    private TextField tfName = new TextField();
    private TextField tfVName = new TextField();
    private TextField tfGebdat = new TextField();
    private TextField tfAnschrifft = new TextField();
    private TextField tfPlz = new TextField();
    private TextField tfOrt = new TextField();
    private TextField tfBlutg = new TextField();
    private Button btSpeichern = new Button();
    private Button btAbbrechen = new Button();

    static BorderPane layout = new BorderPane();
    public Stage stage;
    public Scene scene;

    @Override
    public void start(Stage primaryStage) {

        stage = primaryStage;

        lbAnzeige.setText("Neuer Patient");
        lbAnzeige.setFont(Font.font("Arial", 20.0));

        tfName.setPromptText("Name");
        tfVName.setPromptText("Vorname");
        tfGebdat.setPromptText("Gebdat(jjjj-mm-tt)");
        tfAnschrifft.setPromptText("Strasse");
        tfPlz.setPromptText("PLZ");
        tfOrt.setPromptText("Ort");
        tfBlutg.setPromptText("Blutg");
        btSpeichern.setText("Speichern!");
        btSpeichern.setOnAction(this);

        btAbbrechen.setText("Abbrechen");
        btAbbrechen.setOnAction(this);

        // Panes & Boxes
        VBox topVbox = new VBox(5);
        VBox bottomVbox = new VBox(2);
        FlowPane centerFlowPane = new FlowPane();

        topVbox.getChildren().add(lbAnzeige);
        topVbox.getChildren().add(tfName);
        topVbox.getChildren().add(tfVName);
    
        // 2. Zeile GUI Form
        centerFlowPane.getChildren().add(tfGebdat);
        centerFlowPane.getChildren().add(tfAnschrifft);
        centerFlowPane.getChildren().add(tfPlz);
        centerFlowPane.getChildren().add(tfOrt);
        centerFlowPane.getChildren().add(tfBlutg);
        centerFlowPane.setHgap(2);
        centerFlowPane.setVgap(10);

        bottomVbox.getChildren().add(btSpeichern);
        bottomVbox.getChildren().add(btAbbrechen);

        layout.setTop(topVbox);
        layout.setCenter(centerFlowPane);
        layout.setBottom(bottomVbox);

        scene = new Scene(layout);

    }

    @Override
    public void handle(ActionEvent event) {
        if (event.getSource().equals(btSpeichern)) {
            if (isValidInput()) {
                SQLInterfaceMA.patientenAnlegen(tfName.getText(), tfVName.getText(), tfGebdat.getText(), tfAnschrifft.getText(), tfPlz.getText(), tfOrt.getText(), tfBlutg.getText());
                System.out.println("Patient gespeichert!");
                Main.switchGuiUebersicht();
            } else {
                System.out.println("Ungültige Eingabe! Bitte überprüfen Sie Ihre Daten.");
            }
        }

        if (event.getSource().equals(btAbbrechen)) {
            Main.switchGuiUebersicht();
        }
    }

    // Zusätzliche Methode zur Validierung der Eingabe
    private boolean isValidInput() {
        // Hier können Sie die Validierung der Eingabedaten durchführen
        // Beispiel: Überprüfen, ob alle benötigten Felder ausgefüllt sind
        return !tfName.getText().isEmpty() && !tfVName.getText().isEmpty() && !tfGebdat.getText().isEmpty() && !tfAnschrifft.getText().isEmpty() && !tfPlz.getText().isEmpty() && !tfOrt.getText().isEmpty();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
