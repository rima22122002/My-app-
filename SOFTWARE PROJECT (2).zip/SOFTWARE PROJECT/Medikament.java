import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
public class Medikament {
    private SimpleIntegerProperty pzn;
    private SimpleStringProperty mBez;
    private SimpleStringProperty mWirkstoff;
    private SimpleStringProperty mAnteilWirkstoff;
    private SimpleStringProperty mDarreichungsform;
    private SimpleStringProperty aName;

    public Medikament(Integer pzn, String mBez, String mWirkstoff, String mAnteilWirkstoff, String mDarreichungsform, String aname) {
        this.pzn = new SimpleIntegerProperty(pzn);
        this.mBez = new SimpleStringProperty(mBez);
        this.mWirkstoff = new SimpleStringProperty(mWirkstoff);
        this.mAnteilWirkstoff = new SimpleStringProperty(mAnteilWirkstoff);
        this.mDarreichungsform = new SimpleStringProperty(mDarreichungsform);
        this.aName = new SimpleStringProperty(aname);

    }

    public Integer getpzn() {
        return pzn.get();
    }

    public void setpzn(Integer pzn) {
        this.pzn.set(pzn);
    }

    public SimpleIntegerProperty pznProperty() {
        return pzn;
    }

    public String getMBez() {
        return mBez.get();
    }

    public void setMBez(String mBez) {
        this.mBez.set(mBez);
    }

    public SimpleStringProperty MBezProperty() {
        return mBez;
    }

    public String getMWirkstoff() {
        return mWirkstoff.get();
    }

    public void setMWirkstoff(String mWirkstoff) {
        this.mWirkstoff.set(mWirkstoff);
    }

    public SimpleStringProperty MWirkstoffProperty() {
        return mWirkstoff;
    }

    public String getMAnteilWirkstoff() {
        return mAnteilWirkstoff.get();
    }

    public void setMAnteilWirkstoff(String mAnteilWirkstoff) {
        this.mAnteilWirkstoff.set(mAnteilWirkstoff);
    }

    public SimpleStringProperty MAnteilWirkstoffProperty() {
        return mAnteilWirkstoff;
    }

    public String getMDarreichungsform() {
        return mDarreichungsform.get();
    }

    public void setMDarreichungsform(String mDarreichungsform) {
        this.mDarreichungsform.set(mDarreichungsform);
    }

    public SimpleStringProperty MDarreichungsformProperty() {
        return mDarreichungsform;
    }
  
       public String getAName() {
        return aName.get();
    }

    public void setAName(String aName) {
        this.aName.set(aName);
    }

    public SimpleStringProperty ANameProperty() {
        return aName;
    }
}
// Programmiert von Olcay Anahtar