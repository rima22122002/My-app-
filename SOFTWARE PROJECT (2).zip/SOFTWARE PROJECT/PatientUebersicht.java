import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;

public class PatientUebersicht extends Application implements EventHandler<Event>  {
    private ListView<String> lvwPatienten = new ListView<String>();
    private TableView<Medikament> tblMedikament = new TableView<Medikament>();
    private ObservableList<Medikament> medikamentList = FXCollections.observableArrayList();
    private ObservableList<String> observPatienten = FXCollections.observableArrayList();

    TableColumn<Medikament, String> bezeichnungCol = new TableColumn<Medikament,String>("Medikament");
    TableColumn<Medikament, String> gueltigJahreCol = new TableColumn<Medikament,String>("Aerzte");
    
    private Button btNeuPatient = new Button();
    private Button btAktualisieren = new Button();
    private Button btNeuMedikament = new Button();

    public static BorderPane layout = new BorderPane();
    private HBox untenBox = new HBox();
    private HBox rightupperBox = new HBox();
    private VBox rightBox = new VBox();
    private VBox rightLeftBox = new VBox(8);
    private VBox rightRightBox = new VBox();
    
    private Label lbpID = new Label();
    private Label lbpName = new Label();
    private Label lbpVorname = new Label();
    private Label lbpGebDat = new Label();
    private Label lbpStrasse = new Label();
    private Label lbpPlz = new Label();
    private Label lbpOrt = new Label();
    private Label lbpNummer = new Label();
    private Label lbpBlutg = new Label();  

    private TextField tfpName = new TextField();
    private TextField tfpVorname = new TextField();
    private TextField tfpGebDat = new TextField();
    private TextField tfpStrasse = new TextField();
    private TextField tfpPlz = new TextField();
    private TextField tfpOrt = new TextField();
    private TextField tfpBlutg = new TextField();  
    
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat outputFormat = new SimpleDateFormat("dd.MM.yyyy");
    ObservableList<Patient> patList = SQLInterfaceMA.fuelleListePatienten();

    public Stage stage;
    public static Scene scene;

    @Override
    public void start(Stage primaryStage) {
        stage = primaryStage; 

        btNeuPatient.setText("neuen Patient anlegen");
        btNeuPatient.addEventHandler(ActionEvent.ACTION, this);

        btAktualisieren.setText("Aktualisieren");
        btAktualisieren.addEventHandler(ActionEvent.ACTION, this);
        btAktualisieren.setPrefWidth(115.0);  

        btNeuMedikament.setText("neue Medikament");
        btNeuMedikament.addEventHandler(ActionEvent.ACTION, this);

        for (int i=0; i<patList.size();i++){
            observPatienten.add(patList.get(i).getpName());
        }
        lvwPatienten.setItems(observPatienten);
        lvwPatienten.setOnMouseClicked(this);

        bezeichnungCol.setCellValueFactory(new PropertyValueFactory<Medikament, String>("mBez"));
        bezeichnungCol.setMinWidth(100.0);
        gueltigJahreCol.setCellValueFactory(new PropertyValueFactory<Medikament, String>("aName"));
        gueltigJahreCol.setMaxWidth(150.0);
        tblMedikament.getColumns().addAll(bezeichnungCol, gueltigJahreCol);
        tblMedikament.setVisible(true);

        lbpID.setText("ID-Nummer");
        lbpID.setPrefWidth(200.0);
        tfpName.setPromptText("Name");
        tfpVorname.setPromptText("Vorname");
        tfpGebDat.setPromptText("Gebdat");
        tfpStrasse.setPromptText("Strasse ");
        tfpPlz.setPromptText("PLZ");
        tfpOrt.setPromptText("Ort");
        tfpBlutg.setPromptText("Blutg");  

        lbpName.setText("Name:");
        lbpVorname.setText("Vorname:");
        lbpGebDat.setText("Gebdat:");
        lbpStrasse.setText("Strasse:");
        lbpPlz.setText("PLZ:");
        lbpOrt.setText("Ort:");
        lbpBlutg.setText("Blutg:");  

        rightLeftBox.getChildren().addAll(lbpID, lbpName, lbpVorname, lbpGebDat, lbpStrasse, lbpPlz, lbpOrt, lbpBlutg);

        rightRightBox.getChildren().addAll(lbpNummer, tfpName, tfpVorname, tfpGebDat, tfpStrasse, tfpPlz, tfpOrt, tfpBlutg);

        rightupperBox.getChildren().addAll(rightLeftBox, rightRightBox);
        rightBox.getChildren().addAll(rightupperBox, tblMedikament);

        layout.setLeft(lvwPatienten);
        layout.setBottom(untenBox);
        layout.setRight(rightBox);  

        untenBox.getChildren().add(btNeuPatient);
        untenBox.getChildren().add(btAktualisieren);
        untenBox.getChildren().add(btNeuMedikament);

        scene = new Scene(layout);
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void handle(Event e) {
        if (e.getSource().equals(btNeuPatient)){
            Main.switchGuiErsteller();  
        }
        if (e.getSource().equals(btAktualisieren)){
            observPatienten.clear();
            patList = SQLInterfaceMA.fuelleListePatienten();
            for (int i=0; i<patList.size();i++){
                observPatienten.add(patList.get(i).getpName());
            }
            lvwPatienten.setItems(observPatienten);
        }
        if (e.getSource().equals(lvwPatienten)){
            tblMedikament.setItems(SQLInterfaceMA.getMedikamente(lvwPatienten.getSelectionModel().getSelectedItem().toString()));
            Patient pat= SQLInterfaceMA.getPatientenDaten(lvwPatienten.getSelectionModel().getSelectedItem().toString());

            lbpNummer.setText(pat.getpIDAsString());
            tfpName.setText(lvwPatienten.getSelectionModel().getSelectedItem().toString());
            tfpVorname.setText(pat.getpVorname());  
            tfpGebDat.setText(pat.getpGebDat());
            tfpStrasse.setText(pat.getpStrasse());
            tfpPlz.setText(pat.getpPlzAsString());
            tfpOrt.setText(pat.getpOrt());
            tfpBlutg.setText(pat.getpBlutg());
       }
       if (e.getSource().equals(btNeuMedikament)){
          Main.switchGuiMedikament();
      }
    }
}