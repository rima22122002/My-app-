-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 28, 2014 at 08:08 AM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `MobilerArzt`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_aerzte`
--

CREATE TABLE IF NOT EXISTS `t_aerzte` (
  `aid` decimal(4,0) NOT NULL,
  `aname` varchar(30) NOT NULL,
  `avorname` varchar(20) DEFAULT NULL,
  `afachgebiet` varchar(20) NOT NULL,
  `astrasse` varchar(30) DEFAULT NULL,
  `aplz` decimal(5,0) DEFAULT NULL,
  `aort` varchar(20) DEFAULT NULL,
  `atel` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_aerzte`
--

INSERT INTO `t_aerzte` (`aid`, `aname`, `avorname`, `afachgebiet`, `astrasse`, `aplz`, `aort`, `atel`) VALUES
(3001, 'von Behring', 'Emil', 'Immunologie', 'Biegenstr. 51', 35037, 'Marburg','01701234567' ),
(3002, 'Fleming', 'Alexander', 'Immunologie', 'Urbanstr. 169', 10961, 'Berlin', '01712345678'),
(3003, 'Koch', 'Robert', 'Immunologie', 'Gernsbacher Str. 2', 76530, 'Baden-Baden','01723456789'),
(3004, 'Pasteur', 'Louis', 'Immunologie', 'Ferdinandstr. 35', 12209, 'Berlin', '01734567890'),
(3005, 'Wahnsinn', 'Hella', 'Kinderheilkunde', 'Karlsruher Str. 7a', 10711, 'Berlin', '01745678901'),
(3006, 'Sehen', 'Ann', 'Augenheilkunde', 'Podbielskiallee 77', 14195, 'Berlin', '01756789012'),
(3007, 'Rensolo', 'Gitta', 'HNO', 'Kladower Damm 366', 14089, 'Berlin', '01767890123'),
(3008, 'Schmund', 'Knuth', 'Zahnmedizin', 'Suhler Str. 35-37', 12629, 'Berlin','01778901234'),
(3009, 'Fall', 'Klara', 'Allgemeinmedizin', 'Wilmersdorfer Str. 42', 10627, 'Berlin', '01789012345'),
(3010, 'Utzmich', 'Ben', 'Allgemeinmedizin', 'Assmannshauser Str. 10a', 14197, 'Berlin', '01790123456'),
(3011, 'Trophobie', 'Klaus', 'Kinderheilkunde', 'Reichsstr. 103', 14052, 'Berlin','01790123446'),
(3012, 'Uebel', 'Izmir', 'Innere Medizin', 'Leistikowstr. 2', 14050, 'Berlin', '01787123456'),
(3013, 'Bolika', 'Anna', 'Sportmedizin', 'Schlossstr. 26', 12163, 'Berlin', '01767123456'),
(3014, 'Derbuch', 'Bill', 'Kinderheilkunde', 'Bundesplatz 14', 10715, 'Berlin', '01790123460'),
(3015, 'Paede', 'Otto', 'Orthopaedie', 'Joachim-Friedrich-Str. 16', 10711, 'Berlin', '01793163456'),
(3016, 'Telang', 'Mona', 'Gynaekologie', 'Frankfurter Allee 100', 10247, 'Berlin', '01790155756'),
(3017, 'Deuten', 'Ann', 'Kinderheilkunde', 'Stuewestr. 28', 12621, 'Berlin', '01790123444');

-- --------------------------------------------------------

--
-- Table structure for table `t_patienten`
--

CREATE TABLE IF NOT EXISTS `t_patienten` (
  `pid` decimal(4,0) NOT NULL,
  `pname` varchar(30) NOT NULL,
  `pvorname` varchar(20) NOT NULL,
  `pgebdat` varchar(10) NOT NULL,
  `pstrasse` varchar(30) DEFAULT NULL,
  `pplz` decimal(5,0) DEFAULT NULL,
  `port` varchar(20) DEFAULT NULL,
  `pblutg` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_patienten`
--

INSERT INTO `t_patienten` (`pid`, `pname`, `pvorname`, `pgebdat`, `pstrasse`, `pplz`, `port`,  `pblutg`) VALUES
(5001, 'Stjepanovic', 'Lara', '22.03.1996', 'Adolfsecker Weg 15', 15319, 'Berlin', '0 Negativ'),
(5002, 'Mbathie', 'Eileen', '14.11.2002', 'Dachdecker Weg 8', 16515, 'Oranienburg', 'AB Positiv'),
(5003, 'Kraemer', 'Joschua', '18.07.1997', 'Am Kurpark 4', 16515, 'Oranienburg', 'A Positiv'),
(5004, 'Arndt', 'Philipp', '24.12.2000', 'Boederstrasse 11', 10627, 'Berlin','B Negativ'),
(5005, 'Blum', 'Nils', '09.11.1989', 'Badstrasse 13', 10433, 'Berlin','A Negativ'),
(5006, 'Frey', 'Jacqueline', '31.01.2001', 'Schulstrasse 23', 10422, 'Berlin', 'B Positiv'),
(5007, 'Hartmann', 'Nils', '31.12.2000', 'Poomernstrasse 9', 14401, 'Potsdam', '0 Positiv'),
(5008, 'Atzorn', 'Natalie', '0000-00-00', 'Hauptstrasse 9', 14432, 'Potsdam', 'AB Negativ'),
(5009, 'Dietrich', 'Sebastian', '02.10.1956', 'Goethestrasse 20', 14423, 'Potsdam', 'A Positiv'),
(5010, 'Hackl', 'Julian', '04.02.1968', 'Siemensstrasse 9', 14482, 'Potsdam', '0 Positiv'),
(5011, 'Klug', 'Frederik', '19.08.1964', 'Schollstrasse 12', 14481, 'Potsdam','AB Positiv'),
(5012, 'Wagner', 'Dominic', '01.06.1922', 'Hollerbergstrasse 10', 14482, 'Potsdam','0 Positiv'),
(5013, 'Zorn', 'Angelina', '23.05.1984', 'Hollerbergstrasse 22', 14482, 'Potsdam', 0 Negativ'),
(5014, 'Velte', 'Maik', '12.08.1972', 'In den Krautaeckern 26', 14442, 'Potsdam', '0 Positiv'),
(5015, 'Ruth', 'Sarah', '23.01.2008', 'In den Aeckern 1', 14406, 'Potsdam', 'A Positiv'),
(5016, 'Brandsched', 'Nadine', '17.06.1953', 'Hauptstrasse 78', 14406, 'Potsdam','AB Positiv'),
(5017, 'Baron', 'Alexandra', '0000-00-00', 'Muehlweg 27', 12051, 'Berlin', '0 Positiv'),
(5018, 'Mohr', 'Laura', '0000-00-00', 'Moellerstrasse 34', 12043, 'Berlin', 'B Negativ'),
(5019, 'Scheppner', 'Fabiano', '0000-00-00', 'Britzer Damm 35', 12056, 'Berlin', 'B Positiv'),
(5020, 'Zahn', 'Alisa', '0000-00-00', 'Panoramastrasse 10', 12347, 'Berlin', 'B Negativ'),
(5021, 'Mayer', 'Yannick', '22.08.1976', 'Pestalozzistrasse 30', 12351, 'Berlin','AB Positiv'),
(5022, 'Spiesbach', 'Johannes', '14.02.2012', 'Ritterstrasse 5', 16515, 'Oranienburg', 'B Positiv'),
(5023, 'Istanovic', 'Baris', '06.06.2006', 'Siedlungsstrasse 2', 16515, 'Oranienburg', 'A Positiv'),
(5024, 'Salta', 'Aylin', '03.09.1999', 'Siedlungsstrasse 4', 16515, 'Oranienburg', 'B Positiv'),
(5025, 'Krahl', 'Dennis', '29.07.1977', 'Ueber der Aar 15', 16515, 'Oranienburg', 'A Positiv'),
(5026, 'Becker', 'Sophia', '01.01.1981', 'Vor den Erlen 4', 12433, 'Berlin', 'B Positiv'),
(5027, 'Wolf', 'Saskia', '06.03.1987', 'Webergasse 1', 12342, 'Berlin', 'A Positiv');

-- --------------------------------------------------------



CREATE TABLE IF NOT EXISTS `t_medikamenten` (
  `pzn` decimal(9,0) NOT NULL,
  `mBez` varchar(60) NOT NULL,
  `mWirkstoff` varchar(60) NOT NULL,
  `mAnteilWirkstoff` varchar(40) NOT NULL,
  `mDarreichungsform` varchar(40) NOT NULL,
  PRIMARY KEY (`pzn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `t_medikamenten` (`pzn`, `mBez`, `mWirkstoff`, `mAnteilWirkstoff`, `mDarreichungsform`) VALUES
(07402204 , 'ASS 100 HEXAL 50 St', 'Acetylsalicylsäure','100 mg', 'Tabletten'),
(01476532 , 'BIFITERAL 1000 ml', 'Lactulose','3.35 g', 'Sirup'),
(07422738 , 'ARDEYTROPIN, 50 St', 'Tryptophan','500 mg', 'Tabletten'),
(02740735 , 'NUROFEN 24H SCHMERZP 200MG 2 St', 'Ibuprofen','200 mg', 'Pflaster'),
(12346821  , 'ENALAPRIL/ LERCA ABZ 10/10, 50 St', 'Enalapril maleat','10 mg', 'Filmtabletten'),
(05108564  , 'PRAVASTATIN 1A PHARMA 30MG, 100 St', 'Pravastatin natrium','30 mg', 'Tabletten'),
(07669930  , 'AESCORIN FORTE KAPSELN, 100 St', 'Ibuprofen','200 mg', 'Pflaster'),
(00739478  , 'AGNUS CASTUS AL, 60 St', 'Ethanol 60% (m/m)',	'4 mg', 'Filmtabletten'),
(01830229  , 'CETIRIZIN HEXAL B ALLERGIE, 100 St', 'Cetirizin dihydrochlorid','10 mg', 'Filmtabletten'),
(00876614  , 'ABILIFY 10MG, 49 St', 'Aripiprazol','10 mg', 'Schmelztabletten'),
(18113578  , 'ALLEGRA ALLERGIETAB 20MG, 50 St', 'Bilastin', '20mg', 'Tabletten'),
(07748428  , 'BITOSEN 20MG TAB, 20 St', 'Bilastin', '20mg'),
(04421425  , 'ACESAL, 50 St', 'Acetylsalicylsäure', '500mg',  'Tabletten'),
(2084596   , 'ADONIS COMP.Ampullen, 50X1 ml', 'Adonis vernalis ferm 33d', '100mg', 'Ampullen'),
( 11160899 , 'Jinarc 45mg + 15mg ', 'Tolvaptan', '45 mg/15mg'), 
(6100091   , 'PRAVASTATIN HEUMANN 20MG TABLETTEN Heunet, 100 ST', 'Pravastatin, Natriumsalz', '20mg', 'Tabletten'),
(01502726  , 'B12 ANKERMANN', 'Cyanocobalamin', '1 mg pro Tablette', 'Überzogene Tabletten'),
(03131613  , 'ABASERIL 1 mg Tabletten', 'Cabergolin', ' mg pro 1 Tablette', 'Tabletten'),
(00604927  , 'Guaifenesin 200 mg pro 15 ml Saft', 'Guaifenesin', '200 mg pro 15 ml', 'Saft'),
(01680221 , 'Felodipin 5 mg pro 1 Tablette', 'Felodipin', '5 mg pro 1 Tablette', 'Retard-Tabletten'),
(05466915  , 'Fenchel 1 g pro 1 g Tee', 'Fenchel', '1 g pro 1 g Tee', 'Tee'),
(02796598 , 'Fluvoxamin hydrogenmaleat 50 mg pro 1 Tablette', 'Fluvoxamin hydrogenmaleat', '50 mg pro 1 Tablette', 'Filmtabletten'),
(17603978  , 'Fingolimod hydrochlorid 0,56 mg pro 1 Kapsel', 'Fingolimod hydrochlorid', '0,56 mg pro1 Kapsel', 'Kapseln'),
(02145292  , 'Sulfadiazin silber 10 mg pro 1 g Creme', 'Sulfadiazin silber', '10 mg pro 1 g Creme', 'Creme'),
(08916299  , 'Acetylcystein 200 mg pro 10 ml Saft', 'Acetylcystein', '200 mg pro 10 ml Saft', 'Saft'),
(10832842  , 'Beinwellwurzel-Fluidextrakt 350 mg pro 1 g Creme', 'Beinwellwurzel-Fluidextrakt', '350 mg pro 1 g Creme', 'Creme'),
(00098878  , 'Glycerol 85% 1,8 g pro 3,6 g Lösung', 'Glycerol', '1,8 g pro 3,6 g Lösung', 'Einlauf'),
(00403689  , 'Thiamin nitrat 100 mg pro 1 Tablette', 'Thiamin nitrat', '100 mg pro 1 Tablette', 'Tabletten'),
(02358585  , 'Ciclopirox olamin 10 mg pro 1 g Creme', 'Ciclopirox olamin', '10 mg pro 1 g Creme', 'Creme'),
(04993736  , 'Paracetamol 200 mg pro 5 ml Sirup', 'Paracetamol', '200 mg pro 5 ml Sirup', 'Sirup'),
(15250547 , 'Benzoylperoxid 50 mg pro 1 g Gel', 'Benzoylperoxid', '50 mg pro 1 g Gel', 'Gel');










/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
