import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
  *
  * description
  *
  * @version 1.0 from 16.11.2023
  * @author Denisa Papa 
  */

public class DBConnectionMobilerArzt {

  private static String dburl="jdbc:mysql://localhost/mobiler_arzt";          // noch zu ausfüllen, name der Datenbank
    private static  String userid="root";
    private static String pwd="";
    private static Connection con;
    
   public static Statement Connect() throws SQLException {
   
       con = DriverManager.getConnection(dburl,userid,pwd);   
     Statement stmt = con.createStatement();
     
     
     return stmt;
   
   }
   
   public static void endConnect() throws SQLException{
     con.close();
   }
}
