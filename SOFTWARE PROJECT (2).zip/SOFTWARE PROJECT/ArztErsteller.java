import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.collections.*;
import javafx.scene.text.Font;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;

public class ArztErsteller extends Application implements EventHandler<Event> {
  
  private Label lbAnzeige = new Label();
  private TextField tfId = new TextField();
  private TextField tfName = new TextField();
  private TextField tfVName = new TextField();
  private TextField tfFachgebiet = new TextField();
  private TextField tfStrasse = new TextField();
  private TextField tfPlz = new TextField();
  private TextField tfOrt = new TextField();
  private TextField tfTel = new TextField();  // Hinzugefügtes Telefonattribut
  private Button btSpeichern = new Button();
  private Button btAbbrechen = new Button();
  
  static BorderPane layout = new BorderPane();  
  public Stage stage;
  public Scene scene;

  
  @Override
  public void start(Stage primaryStage) {

    stage = primaryStage;
    
    lbAnzeige.setText("Arzt Kontaktdaten");
    lbAnzeige.setFont(Font.font("Arial",20.0));
    
    tfId.setPromptText("Id");
    
    tfName.setPromptText("Name");
    
    tfVName.setPromptText("Vorname");
    
    tfFachgebiet.setPromptText("Fachgebiet");
    
    tfStrasse.setPromptText("Strasse");
    
    tfPlz.setPromptText("PLZ");
    
    tfOrt.setPromptText("Ort");
    
    tfTel.setPromptText("Telefon");
    
    //btSpeichern.setText("Speichern!");  
    //btSpeichern.addEventHandler(ActionEvent.ACTION, this);
    
    btAbbrechen.setText("Abbrechen");
    btAbbrechen.addEventHandler(ActionEvent.ACTION, this);
    
    // Panes & Boxes
    VBox topVbox = new VBox(5);
    VBox bottomVbox = new VBox(2);
    FlowPane centerFlowPane = new FlowPane();   
  
    topVbox.getChildren().add(lbAnzeige);  
    topVbox.getChildren().add(lbAnzeige);
    topVbox.getChildren().add(tfId);
    topVbox.getChildren().add(tfName);
    topVbox.getChildren().add(tfVName);
     
      
    centerFlowPane.getChildren().add(tfFachgebiet);
    centerFlowPane.getChildren().add(tfStrasse);
    centerFlowPane.getChildren().add(tfPlz);
    centerFlowPane.getChildren().add(tfOrt);
    centerFlowPane.getChildren().add(tfTel);  // Hinzugefügtes Textfeld für Telefon
    centerFlowPane.setHgap(2);
    centerFlowPane.setVgap(10);
      
    //bottomVbox.getChildren().add(btSpeichern);
    bottomVbox.getChildren().add(btAbbrechen);
      
    layout.setTop(topVbox);
    layout.setCenter(centerFlowPane);
    layout.setBottom(bottomVbox);
      
    scene = new Scene(layout);
  }
  
  public static void main(String[] args) {
    launch(args);
  }

  @Override
  public void handle(Event e) {
    if (e.getSource().equals(btAbbrechen)){
      Main.switchGuiUebersicht(); 
    }
    if (e.getSource().equals(btSpeichern)){
      //SQLInterfaceMA.getpatArzt(tfId.getText(), tfName.getText(), tfVName.getText(), tfFachgebiet.getText(), tfStrasse.getText(), tfPlz.getText(), tfOrt.getText(), tfTel.getText());
      Main.switchGuiUebersicht(); 
    
    }
  
    
  }
  }
//}
// Programmiert von Rima
